﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        void BubbleSort1(string a)
        {
            string[] A = a.Split();

            for (int i = 0; i < A.Length; i++)
            {
                for (int j = 0; j < A.Length - 2; j++)
                {
                    if (A[j].Length > A[j + 1].Length)
                    {

                        string z = A[j];
                        A[j] = A[j + 1];
                        A[j + 1] = z;


                    }


                }

                listBox3.Items.Add(A[i]);
            }



        }
        void BubbleSort_AZ(string a)
        {
            string[] A = a.Split();

            for (int i = 0; i < A.Length; i++)
            {
                for (int j = 0; j < A.Length - 2; j++)
                {
                    if (String.Compare(A[j], A[j + 1]) > 0)
                    {

                        string z = A[j];
                        A[j] = A[j + 1];
                        A[j + 1] = z;


                    }


                }

                listBox3.Items.Add(A[i]);
            }

        }
        void set(string s)
        {
            listBox1.Items.Clear();
            listBox3.Items.Clear();
            string[] st = s.Split();
            int n = st.Length;

            for (int j = n - 1; j >= 0; j--)
            {

                for (int i = j + 1; i < n; i++)
                {
                    if (st[j] == st[i])
                    {
                        if (i + 1 < n)
                        {
                            st[i] = st[i + 1];
                        }
                        n--;
                    }

                }

            }


            for (int i = 0; i < (1 << n); i++)
            {
                listBox1.Items.Add("{");

                for (int j = 0; j < n; j++)
                {

                    if ((i & (1 << j)) > 0)
                    {
                        listBox1.Items.Add(st[j]);
                    }

                }
                listBox1.Items.Add("}");
                listBox1.Items.Add(" ");
            }

        }

        string rt;
        private void запускToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rt = "";
            listBox3.Items.Clear();
            string s = textBox1.Text;
            if (s.Length == 0) 
            { 
                textBox1.BackColor = System.Drawing.Color.LightCoral;
                MessageBox.Show("Введіть множину перед тим, як виконувати прогрмаму");
               
        
            }
            else { 
            string[] st = s.Split();
            int n = st.Length;
            set(s);
            string[] spp = new string[listBox1.Items.Count];
            int m = listBox1.Items.Count;
            for (int j = 0; j < m; j++)
            {
                spp[j] = listBox1.Items[j].ToString();
                if (spp[j] != "")
                {
                    

                    rt = rt+ spp[j];
                 
                    

                }
                else
                {
                    rt = "";
                }

            }
            BubbleSort1(rt);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox1, "Введіть елементи множини через пробіл");
        }

        private void заАлфавітомToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            if (listBox1.Items.Count == 0) 
            { 
            MessageBox.Show("Введіть множину перед тим, як виконувати прогрмаму або натисныть Запуск");
            }
            else 
            { 
            BubbleSort_AZ(rt);
            }
        }

        private void заДовжиноюРядкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Введіть множину перед тим, як виконувати прогрмаму або натисніть Запуск");
            }
            else
            {
                BubbleSort1(rt);
            }

        }

        private void допомогаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] sr1 = File.ReadAllLines("help.txt");
            for (int i = 0; i < sr1.Count();i++ )
            {
                richTextBox1.Text = richTextBox1.Text+sr1[i]+"\n";
            }
            richTextBox1.Visible = true;
        }

    

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            textBox1.BackColor = System.Drawing.Color.White;
        }

        private void richTextBox1_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
        }

    }
}
